// export default function tailwind(classNames: string): {[key: string]: string};
// export function getColor(color: string): string;

// export function create(
// 	styles: object
// ): {
// 	tailwind: (classNames: string) => {[key: string]: string};
//   theme: object;
// 	getColor: (color: string) => string;
//   getBgColor: (color: string) => string;
// };
